<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form  action="htm.php" method="get">
		username:<input type="text" name="username"><br>
		password:<input type="password" name="pwd"><br>
		email:<input type="email" name="email"><br>
		DOB: <input type="date" name="DOB">
				<input type="submit" name="submit">

	</form>

</body>
</html>

