<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="connectio2.php" method="post">
		<input type="text" name="data">
		<input type="submit" name="submit">

	</form>
	<?php
	$conn = mysqli_connect("localhost","root","","happy");
	/*$sql = "CREATE table demo (id int(10)not null PRIMARY KEY AUTO_INCREMENT,data varchar(255) not null)";*/
	if(isset($_POST['submit']))
	{
		$data = $_POST['data'];
		$sql = "INSERT into demo (data) VALUES ('$data');";
		if(mysqli_query($conn,$sql)) 
		{
			echo "data inserted";
		}
		else{
			echo "data not inserted";
		}
	}
	    
?>
</body>
</html>
