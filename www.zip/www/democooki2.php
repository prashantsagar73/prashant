<?php 
/*$file = fopen("newfile.txt","w");
fwrite($file,"sadhf");
fclose($file);*/

$file2 = fopen("newfile.txt","r");
echo fread($file2,filesize("newfile.txt"));
//echo fgets($file2);
fclose($file2);
readfile("newfile.txt","r");
while(!feof($file))
{
	echo fgets($file);
	echo "<br>";
 }
 ?>
