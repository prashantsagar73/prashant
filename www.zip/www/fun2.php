<?php
include('fnc.php')  
 ?>
 <p>this is paragraph</p>
</body>
</html>