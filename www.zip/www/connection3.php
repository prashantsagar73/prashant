<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	$conn = mysqli_connect("localhost","root","","happy");
	$sql = "SELECT * from demo ";
	$results = mysqli_query($conn,$sql); 
	/*if(mysqli_num_rows($results) > 0)
 
		{
			echo "data found";
		}
		else{
			echo "data not found";
		}*/
		while($content = mysqli_fetch_array($results))
		{//var_dump($data);
		 echo $content['data']."<br>";
		}
 

	 ?>
	 

</body>
</html>