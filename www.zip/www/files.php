<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="files.php" method="post" enctype="multipart/form-data">
		<input type="file" name="upload">
		<input type="submit" name="submit">

		</form>
		<?php
		if(isset($_POST['submit']))
		{
			var_dump($_FILES['upload']);
		} 

		?>

</body>
</html>