<?php
$file = "abc.txt";
if(unLink($file))
{
	echo "delete successfully";
}
else
{
	echo "delete.error";
}


  ?>