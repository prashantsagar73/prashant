<?php
include 'dbconnection.php';
if(isset($_POST['submit'])) 
{
$cart = $_POST['order'];
echo $cart;
}

 ?>