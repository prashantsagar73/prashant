<?php
echo $_COOKIE['abcd'];

?>