<?php
include 'dbconnection.php';
session_start();
if(isset($_POST['submit']))
{
	$file = $_FILES['file'];
	$fileName = $file['name'];
	$fileSize = $file ['size'];
	$fileTmpName = $file['tmp_name'];
	$FileuploadName = time()."-".$fileName;
	$destination = "uploads/".$FileuploadName; 


	 $fileALLowed = array('jpg','png','jif','bmp');
	 $fileExt = explode(".", $fileName);
	 $fileActExt = strtoLower(end($fileExt));
	if(!in_array($fileActExt, $fileALLowed))
	{
		header("location:home1.php?error=file not allowed");
	}
	else
	{  if($fileSize > 300000)
		{
			header("location:home1.php?error= file size must be 300kb");
		}
		else

		{
	      if(!move_uploaded_file($fileTmpName, $destination))
	{
		  header("location:home1.php?error=file not uploaded");
	}
	else
	{
		date_default_timezone_get("Asia/calcutta");
        $date = date("d-m-y h:i:s");
        $userEmail = $_SESSION['email'];
        $sql = "INSERT into uploadedimages (imageName,uploaded_at,uploaded_by)VALUES ('$FileuploadName','$date','$userEmail')";


        $abc = mysqli_query($conn,$sql);
        if(!mysqli_query($abc)< 1)
        {
        	header("location:home1.php?error=file uploaded but not saved");
        }
        else
        {
        	header("location:home1.php?error=file  uploaded");
        }
	}
}
}

}



?>