
<?php
echo "hello";  
print ("hello");
echo "<h1>";
echo "this is heading text";
echo "</h1>";
echo"<p>This is a paragraph tag </p>";
$var1 = "this is string";
$var2 = 10;
$var3 = 10.2;
$var4 = true;
$var5 = NULL;
echo $var1;
 echo $var2;
$var6 = array(1,"abcd",2,3,4,5);
echo "<br>";
echo $var6[1];
var_dump($var6);
echo = href=;



?>