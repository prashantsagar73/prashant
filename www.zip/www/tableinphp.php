<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php $values = array(1,2,3,4,5,6,7,8,9);?>
	<table border="1px">
		<tr>
			<td><?php echo $values[0]; ?></td>
			<td><?php echo $values[1]; ?></td>
			<td><?php echo $values[2]; ?></td>

		</tr>
		<tr>
			<td><?php echo $values[4]; ?></td>
			<td><?php echo $values[5]; ?></td>
			<td><?php echo $values[6]; ?></td>

		</tr>
	</table>

</body>
</html>