<?php
include 'dbconnection.php';
session_start();

if(!isset($_SESSION['username']))
{
	header("location:login.php?error=you must.login first");
}
   echo $_SESSION['username'];
   echo $_SESSION['email'];
   echo $_SESSION['gender'];
   echo $_SESSION['dob'];
  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title>my page</title>
  	<link rel="stylesheet" type="text/css" href="bootstrap.min/bootstrap.min.css">
  	<script type="bootstrap.min/jquery.min.js"></script>
  	<script type="bootstrap.min/bootstrap.min.js"></script>

  </head>
  <body>
  	<h1>welcome to page</h1>
  	<form action="logout.php" method="post">
  		<input type="submit" name="logout" value="logout">
  		
  	</form>
  	<form action="upload.php" method="post" enctype="multipart/form-data">
  		<input type="file" name="file">
  		<input type="submit" name="submit">
  	</form>
  	<button onclick="uploads()">upload</button><br>
            <script type="text/javascript">
            function upload()
            {
            	return document.getElementByID('file').click();
            }
            function submits()
            {
            	return document.getElementByID('submit').click();
            }
            </script>
  	<?php
  	$userEmail = $_SESSION['email'];
  	$sql = "SELECT * From uploadedImages WHERE uploaded_by='$userEmail'";
  	$result = mysqli_query($conn,$sql);
  	if(mysqli_num_rows($result) > 0)
  	{	
  		
  		while($data = mysqli_fetch_assoc($result))
  		{
  			$imageName = $data['imageName'];
  			$imageId = $data['id'];
  			echo "<img src='uploads/".$data['imageName']."' height='200'>";
            echo "<p>uploaded_at:".$data['uploaded_at']."</p>";
            echo "<form action='fetch.php' method='post' enctype='multipart/data' class='uploads'>"; 
            echo "<input type='hidden' name='imageid' value='".$imageId."''>";
            echo "<input type='hidden' name='imageName' value='".$imageName."'>";
            echo "<input type='submit' name='submit' value='delete'>";
            echo "</form>";        

  		}
  	}


  	  ?>

  	  <div class="container-fluid" style="border: 1px solid black">
  	  	<div class="row">
  	  		<div class="col-sm-4">
  	  			<img src="3.jpg" class="img-responsive"> 
  	  			</div>
  	  				<div class="col-sm-4">
  	  			<img src="3.jpg" class="img-responsive">
  	  				</div>
  	  				<div class="col-sm-4">
  	  			<img src="3.jpg" class="img-responsive">
  	  				</div>
  	  		
  	  	</div>
  	  	<div class="row">
  	  		<div class="col-md-4">
  	  			<div class="cotainer">
  	  				<form>
  	  					<span onclick="decr()"> < </span>
  	  					<input type="text" name="order" value="0" id="num" style="width: 13px">
  	  					
  	  					<span onclick="incr()"> > </span>
  	  					<input type="submit" name="submit" value="add_to_cart">
  	  				</form>
  	  			</div>
  	  		</div>
  	  		<div class="col-md-8">
  	  		</div>
  	  			</div>
  	  			 <script type="text/javascript">
  	  			 	function incr()
  	  			 	{
  	  			 		var num = Number(document.getElementById('num').value);
  	  			 		document.getElementById('num').value = num + 1;
  	  			 	}
  	  			 	function decr()
  	  			 	{
  	  			 		var num = Number(document.getElementById('num').value);
  	  			 		if((num-1) >= 0)
  	  			 		{
  	  			 	       //aleart("value can't be negative");
  	  			 			document.getElementById('num').value = num - 1;
  	  			 		}

  	  			 	}

  	  			 </script>


  	  
  	  	<!--<div class="row">
  	  		<div class="col-sm-4">
  	  			<img src="3.jpg" class="img-responsive">
  	  				</div>
  	  				<div class="col-sm-4">
  	  			<img src="3.jpg" class="img-responsive">
  	  				</div>
  	  				<div class="col-sm-4">
  	  			<img src="3.jpg" class="img-responsive">
  	  				</div> 

  	  			<table class="table table-hover">
  	  				<tr>
  	  					<th>heading1</th>
  	  					<th>heading1</th>
  	  					<th>heading1</th>
  	  				</tr>
  	  				<tr>
  	  					<td>heading1</td>
  	  					<td>heading1</td>
  	  					<td>heading1</td>
  	  				</tr>
  	  				<tr>
  	  					<td>heading1</td>
  	  					<td>heading1</td>
  	  					<td><img src="3.jpg" class="img-thumbnail" width="180px"> </td>
  	  				</tr>


  	  				
  	  			</table>-->	
  	  		
  	  
  
  </body>
  </html>