

$values = array(1,2,3,4,5,6,7,8,9);
echo "<table border='1px'>";
echo "<tr>";
echo "<td>".$values[0]."</td>";
echo "<td>".$values[1]."</td>";
echo "<td>".$values[2]."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>".$values[3]."</td>";
echo "<td>".$values[4]."</td>";
echo "<td>".$values[5]."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>".$values[6]."</td>";
echo "<td>".$values[7]."</td>";
echo "<td>".$values[8]."</td>";
echo "</tr>";
echo "</table>";
?>