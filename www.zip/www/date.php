<?php
date_default_timezone_get("asia/calcutta");
//echo date("D-m-y h:i:s");
echo date("M");
echo date("Y");

  ?>