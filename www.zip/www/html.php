<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form>
		<input type="text" name="username">
		<input type="passeord" name="pwd">
		<input type="submit" name="submit">
	</form>

</body>
</html>