<?php
setcookie("happy","1234",time() - 200000);
echo $_COOKIE['abcd'];
  ?>