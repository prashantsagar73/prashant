<?php 
class demo
{
	function display()
	{
		echo "hello world";
	}
}

function abcd()
{
	$obj = new demo();
$obj->display();
}
 abcd();
?>