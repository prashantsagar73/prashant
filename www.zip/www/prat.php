<!DOCTYPE 
<html>
<head>
	<title></title>
</head>
<body>
<form action="prat.php" method="post">
	<input type="text" name="name">
	<input type="submit" name="submit">
    </form>
    <?php 
    if (isset($_POST['submit'])) 
    {
       $data = $_POST['abcd']
    }


    ?>

</body>
</html>