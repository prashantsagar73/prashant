<?php
/*$var = "this is string";
echo strlen($var);
echo str_word_count($var);
echo strrev($var);
echo str_replace("string", "text",$var); 
echo strpos($var,"string");
$var = array('one' =>1, "two" => 2);
echo var_dump($var);
define("N",1,true);
echo N;
asithmetic oprators : +,-,*,/,%
assignment oprators : =,+=,-+,*= ....
comprasion oprators : ==, ===,!=,!==,<=,=>,<> ...;
string oprators : .,.=;
logical oprators : and,&&,or,||,!,xor 
echo "<br>";
$one = "1";
$a = 1;
if($one === $a)
{
	echo"equal";
}
else
{
	echo " not equal";

}
$ab = "abcd";
$ac = "efgh";
echo "<br>";
echo $ab.$ac;
echo "<br>";
echo $ab;
echo "<br>";
if( 1== 1 && "1" == 1)
{
	echo "equal";
}
else
{
	echo "not equal";
}*/

echo 11|10;
$values = array(1,gfga,3,4,5,6,7,8,9);
$i = 0;
/*for ($i = 0;$i<9;$i++)
{
	echo "<br>".$values[$i];
}*/
/*while($i<9)
{
	echo "<br>".$values[$i];
	$i++;
}
do{
	echo"<br>".$values[$i];
	$i++;
}
while($i<9);

foreach($values as $val)
{
	echo "<br>".$val;
}*/
$assocArr = array("a" => 1,"b" => 2,"c" => 3,"d" => 4);
 foreach($assocArr as $key => $value)
 {
 	echo "<br>".$key." => ".$value;
 }
 ksort($values);
 echo var_dump($values);
 
 arsort($assocArr);
echo var_dump($assocArr);
function sum($a,$b,$c,$d)
{
	echo $a+$b+$c+$d;
}
sum(6,7,4,2);
//superglobal

?>





