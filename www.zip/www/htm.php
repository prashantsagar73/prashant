<?php 

/*if(!empty($_GET['username']))
{
	echo $_GET['username'];
	echo "<br>";
	echo $_GET['pwd'];
}


echo $_SERVER['PHP_SELF'];
echo "<br>";
echo $_SERVER['HTTP_HOST'];
echo "<br>";
echo $_SERVER['SERVER_NAME'];
echo "<br>";
echo $_SERVER['SERVER_ADDR']*/

echo "<table border='1px'>";
echo "<tr>";
echo "<td>username</td>";
echo "<td>".$_GET['username']."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>password</td>";
echo "<td>".$_GET['pwd']."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>email</td>";
echo "<td>".$_GET['email']."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>DOB</td>";
echo "<td>".$_GET['DOB']."</td>";
echo "</tr>";
echo "</table>";






?>