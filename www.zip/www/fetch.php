<?php
include 'dbconnection.php';
if(isset($_POST['submit']))

{
$imageName = $_POST['imageName'];
$imageId = $_POST['imageid'];
//echo "imagename:".$imagename."<br>""iamgeid:".$imageid;
$file = "uploads/".$imageName;
if(!unlink($file))
{
	header("location:home1.php?error=file not deleted");
 }
 else
 {
	$sql = "DELETE from uploadedimages WHERE id='$imageId'";
	if(!mysqli_query($conn,$sql))
   		 {
   		 	header("location:home1.php?error=not deleted");
   		 } 
   		 else
   		 {
   		 	header("location:home1.php?error=Success");
   		}
    }   	
}

 ?>"